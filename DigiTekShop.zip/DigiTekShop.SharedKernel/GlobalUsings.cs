﻿global using System;
global using System.Collections.Generic;
global using System.Linq;
global using System.Text;
global using System.Threading.Tasks;
global using System.Net.Mail;
global using System.Diagnostics;
global using System.Text.RegularExpressions;
global using DigiTekShop.SharedKernel.Exceptions.Common;

