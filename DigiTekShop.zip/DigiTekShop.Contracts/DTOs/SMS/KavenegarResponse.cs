﻿namespace DigiTekShop.Contracts.DTOs.SMS
{
    public class KavenegarResponse
    {
        public bool IsSuccess { get; set; }
        public string ErrorMessage { get; set; } = string.Empty;
    }
}