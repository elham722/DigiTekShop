﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DigiTekShop.Contracts.DTOs.Auth.EmailConfirmation
{
    public record ConfirmEmailRequestDto(string UserId, string Token);
}
