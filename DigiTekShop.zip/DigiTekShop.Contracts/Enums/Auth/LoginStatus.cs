﻿namespace DigiTekShop.Contracts.Enums.Auth;
public enum LoginStatus { Unknown = 0, Success = 1, Failed = 2, LockedOut = 3, RequiresMfa = 4 }

