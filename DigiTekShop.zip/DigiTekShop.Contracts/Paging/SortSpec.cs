﻿namespace DigiTekShop.Contracts.Paging
{
    public sealed record SortSpec(string Field, bool Desc = false);
}
