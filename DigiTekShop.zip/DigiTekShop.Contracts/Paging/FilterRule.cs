﻿namespace DigiTekShop.Contracts.Paging
{
    public sealed record FilterRule(string Field, string Op, string? Value);
}
