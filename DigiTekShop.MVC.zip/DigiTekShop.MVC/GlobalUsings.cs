﻿global using DigiTekShop.MVC.Models;
global using DigiTekShop.MVC.Services;
global using Microsoft.AspNetCore.Authentication.Cookies;
global using Microsoft.AspNetCore.Mvc;
global using System.Diagnostics;
global using System.Text;
